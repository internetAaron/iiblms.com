TA Team Management
==================

Create and manage your team member present them in the easiest way. Provide useful shortcodes and tools for both end users and developers.


Change Log
----------

Version 1.0.1
- Fix bug: warning on archive pages

Version 1.0.0
- Initialize